//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_BATTLESHIPGAME_H
#define BATTLESHIP_BATTLESHIPGAME_H

#include <vector>
#include "PlayerFiles/HumanPlayer.h"
#include "PlayerFiles/AiFiles/AiPlayer.h"
#include "Board.h"
#include "Move.h"
#include "Ship.h"
#include "View.h"


namespace BattleShip {
    class BattleShipGame: public GameAttributes {

    public:
        //constructors
        explicit BattleShipGame(std::ifstream &file);
        BattleShipGame();

        
        void determineStartingPlayer();
        void changeTurn();

        //methods

    protected:
        HumanPlayer makeHuman();
        AiPlayer makeAI();
        GameAttributes attributes;

       // Move getValidMove(HumanPlayer player);
       // Move getValidMove(AiPlayer player);



        int playerTurn;
        //inherited from GameAttributes
//        std::vector<Ship> ships;
//        int totalShips;
//        int rows;
//        int cols;


        bool parseInput(std::stringstream &input);
        bool parsedSuccessfully;



    };
}


#endif //BATTLESHIP_BATTLESHIPGAME_H
