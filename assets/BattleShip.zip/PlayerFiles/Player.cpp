//
// Created by Sarah Gerard on 2019-05-30.
//

#include "Player.h"

BattleShip::Board &BattleShip::Player::getBoard() {
    return board;
}

BattleShip::Player::Player(std::vector<BattleShip::Ship> ships, BattleShip::Board board, std::string(name)) :
ships(ships), board(board), view(), name(name){
    std::map<char, int> map;
    for (auto ship : ships){
        map.emplace(ship.piece, ship.health);
    }
    shipHealths = map;
}

void BattleShip::Player::initializeName() {


}
