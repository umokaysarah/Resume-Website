//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include <string>
#include <vector>
#include <map>
#include "../Board.h"
#include "../Ship.h"
#include "../GameAttributes.h"
#include "../View.h"
#include "../ShipPlacement.h"

namespace BattleShip {
    class Player {
    public:
        Player(std::vector<Ship> ships, Board board, std::string name);


        Board &getBoard();
        virtual void initializeName();


        std::vector<Ship> ships;
        std::map<char, int> shipHealths;
        View view;
        Board board;
        std::string name;

    };
}


#endif //BATTLESHIP_PLAYER_H
