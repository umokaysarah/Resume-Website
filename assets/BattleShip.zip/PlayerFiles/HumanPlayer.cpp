//
// Created by Sarah Gerard on 2019-05-30.
//

#include <iostream>
#include "HumanPlayer.h"
#include "../Move.h"


BattleShip::HumanPlayer::HumanPlayer(std::string name, std::vector<Ship> ships, Board board):
 Player(ships, board, name) {

}

void BattleShip::HumanPlayer::placeShips() {
    const int numRows = getBoard().getNumRows();
    const int numCols = getBoard().getNumCols();
    int row = 0;
    int col;
    char orientation;
    ShipPlacement placement;
    int i = 0;
        for (const auto &ship : shipHealths) {
            std::cout << name << ", do you want to place " << ship.first << " horizontally or vertically?" << std::endl;
            std::cout << "Enter h for horizontal or v for vertical" << std::endl;
            std::cout << "Your choice: ";
            std::cin >> orientation;
            std::cout << name << ", enter the row and column you want to place " << ship.first <<
                      ", which is " << ship.second << " long, at with a space in between row and col: ";
            std::cin >> row >> col;
            do {
                if (orientation == 'h') {
                    placement.rowStart = row;
                    placement.colStart = col;
                    placement.rowEnd = placement.rowStart;
                    placement.colEnd = placement.colStart + ship.second - 1;
                } else {
                    placement.rowStart = row;
                    placement.colStart = col;
                    placement.rowEnd = placement.rowStart + ship.second - 1;
                    placement.colEnd = placement.colStart;
                }
            } while (!getBoard().canPlaceShipAt(placement));
            getBoard().AddShip(ship.first, placement);
            getBoard().display();
            //view.showPlacementBoard(*this);
            ships[i].placement = placement;
            i++;

        }
}


