//
// Created by Sarah Gerard on 2019-06-03.
//

#ifndef BATTLESHIP_CHEATINGAI_H
#define BATTLESHIP_CHEATINGAI_H

#include "AiPlayer.h"

namespace BattleShip {
    class CheatingAi : public AiPlayer{

    };
}

#endif //BATTLESHIP_CHEATINGAI_H
