//
// Created by Sarah Gerard on 2019-06-03.
//

#ifndef BATTLESHIP_HUNTAI_H
#define BATTLESHIP_HUNTAI_H


#include "AiPlayer.h"

namespace BattleShip {
    class HuntAi :public AiPlayer {

    };
}


#endif //BATTLESHIP_HUNTAI_H
