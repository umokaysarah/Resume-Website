//
// Created by mfbut on 3/9/2019.
//

#ifndef BATTLESHIP_AIPLAYER_H
#define BATTLESHIP_AIPLAYER_H
#include <random>
#include "../Player.h"
#include "../../GameAttributes.h"
#include "../../View.h"

namespace BattleShip {
class Move;
class AiPlayer : public Player {
 public:
    friend class HumanVsAI;
    friend class AIVsAI;
    AiPlayer(std::vector<Ship> ships, Board board, int type, std::vector<std::pair<int,int>> possibleMoves);

  static void seed_random_number_generator(int seed);
  virtual void placeShips();
  void initializeName() override;
  virtual void setName(std::string Name);
    int type;


 protected:
  static std::mt19937 randomNumberGenerator;
    std::vector<std::pair<int,int>> possibleMoves;
public:
    std::vector<std::pair<int, int>> &getPossibleMoves();


    //1 = cheating, 2 = random, 3 = hunt

 private:
  static int nextAiId;
  const int aiId;
};
}

#endif //BATTLESHIP_AIPLAYER_H
