//
// Created by Sarah Gerard on 2019-06-03.
//

#ifndef BATTLESHIP_RANDOMAI_H
#define BATTLESHIP_RANDOMAI_H


#include "AiPlayer.h"

namespace BattleShip {
    class RandomAi: public AiPlayer {

    };
}


#endif //BATTLESHIP_RANDOMAI_H
