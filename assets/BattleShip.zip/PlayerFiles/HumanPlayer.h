//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_HUMANPLAYER_H
#define BATTLESHIP_HUMANPLAYER_H

#include "Player.h"


namespace BattleShip {
    class Move;
    class HumanPlayer : public Player {
    public:
        HumanPlayer(std::string name, std::vector<Ship> ships, Board board);

        virtual void placeShips();


    };
}


#endif //BATTLESHIP_HUMANPLAYER_H
