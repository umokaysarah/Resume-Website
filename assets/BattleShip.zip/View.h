//
// Created by Sarah Gerard on 2019-05-31.
//

#ifndef BATTLESHIP_VIEW_H
#define BATTLESHIP_VIEW_H

#include "Board.h"
//#include "PlayerFiles/Player.h"
namespace BattleShip {
    class Player;
    class View {

    public:
        View() = default;

        Board makeFiringBoard(Player player);

        void showPlacementBoard(Player player);
        void showFiringBoard(Player player, Player otherPlayer);

        void showPlacementBoard(Player* player);
        void showFiringBoard(Player* player, Player* otherPlayer);

       // Board board;
    };

}


#endif //BATTLESHIP_VIEW_H
