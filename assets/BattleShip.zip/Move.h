//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_MOVE_H
#define BATTLESHIP_MOVE_H

#include <string>

namespace BattleShip {
    class Player;
    class Board;
    class Move {
    public:
        explicit Move(const Player& player, const Player& otherPlayer);

        bool isValid(const Board& board) const;
        //Board make(Board board);
        void displayResult();

        int row, col;

        int& getRow();
        int& getCol();

    private:
        const Player& player;
        const Player& otherPlayer;



    };
}

#endif //BATTLESHIP_MOVE_H
