//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_BOARD_H
#define BATTLESHIP_BOARD_H

#include <string>
#include <vector>

namespace BattleShip {
    class Ship;
    class Move;
    class ShipPlacement;
    class Board {

    public:
        friend class View;
        Board(int rows, int cols, char blankchar);
        Board();

        std::vector<std::string> boardState;

        void display();

        const int getNumRows() const;
        const int getNumCols() const;
        char& at(int row, int col);
        const char at(int row, int col) const;

        bool canPlaceShipAt(ShipPlacement place) const;
        void AddShip(char ship, ShipPlacement place);
        void makeMove(Move move);

        char blankChar;
        char hitChar;
        char missChar;

    private:
        int rows;
        int cols;

    };
}


#endif //BATTLESHIP_BOARD_H
