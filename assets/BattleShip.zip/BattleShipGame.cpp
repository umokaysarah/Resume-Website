//
// Created by Sarah Gerard on 2019-05-30.
//

#include "BattleShipGame.h"
#include <iostream>
#include <sstream>
#include <string>

#include "GameTypeFiles/HumanVsHuman.h"
#include "GameTypeFiles/AIVsAI.h"
#include "GameTypeFiles/HumanVsAI.h"



void BattleShip::BattleShipGame::determineStartingPlayer() {
    playerTurn = 0;

}

void BattleShip::BattleShipGame::changeTurn() {
    playerTurn = (playerTurn + 1) % 2;
}

BattleShip::HumanPlayer BattleShip::BattleShipGame::makeHuman() {
    std::string name;
    //while(true){
    std::cout << "Player "<< playerTurn+1 <<" please enter your name: ";
    std::cin>>name;
//    std::string line;
//    std::getline(std::cin, line);
//    std::stringstream InName(line);
//    if (parseInput(InName)) {
//        name = line;
//        break;
//    }else{
//        continue;
//    }
  //  }
    HumanPlayer player(name, ships, basicBoard);
    basicBoard.display();
    player.placeShips();
    changeTurn();

    return player;
}


bool BattleShip::BattleShipGame::parseInput(std::stringstream &input) {
    parsedSuccessfully = static_cast<bool>(input); //input must start out as being good
    std::string name;
    input >> name;

    parsedSuccessfully = parsedSuccessfully && static_cast<bool>(input);
    std::string leftovers;
    input >> leftovers;
    //and we weren't able to read anything after the row and col
    return parsedSuccessfully = parsedSuccessfully && !input;

}


BattleShip::BattleShipGame::BattleShipGame(): playerTurn(0), parsedSuccessfully(false) {

}

BattleShip::BattleShipGame::BattleShipGame(std::ifstream &file) :
GameAttributes(file), playerTurn(0), parsedSuccessfully(false){

}

BattleShip::AiPlayer BattleShip::BattleShipGame::makeAI() {
    std::vector<std::pair<int, int>> possibleMoves;
    for(int i = 0; i < basicBoard.getNumRows(); i++){
        for(int p = 0; p < basicBoard.getNumCols(); p++){
            std::pair<int, int> newPair;
            newPair.first = i;
            newPair.second = p;
            possibleMoves.push_back(newPair);
        }
    }
    int Cheating = 1, Random = 2, Hunt = 3;
    int type;
    int PlayerType;
    while(true) {
        std::cout << "What AI do you want?\n1. Cheating AI\n2. Random AI\n3. Hunt Destroy AI"
                  << std::endl;
        std::cout << "Your choice: ";
        std::cin >> type;
        if (type == Cheating) {
            PlayerType = Cheating;
            break;
        } else if (type == Random) {
            PlayerType = Random;

            break;
        } else if (type == Hunt) {
            PlayerType = Hunt;
            break;
        } else {
            continue;
        }
    }
    AiPlayer player(ships, basicBoard, PlayerType, possibleMoves);
    player.placeShips();
    return player;
}



