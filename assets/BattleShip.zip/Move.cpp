//
// Created by Sarah Gerard on 2019-05-30.
//

#include "Move.h"
#include "PlayerFiles/Player.h"
#include <iostream>

BattleShip::Move::Move(const BattleShip::Player &player, const BattleShip::Player &otherPlayer):
        player(player), otherPlayer(otherPlayer), row(-99), col(-98) {

}


int &BattleShip::Move::getRow() {
    return row;
}

int &BattleShip::Move::getCol() {
    return col;
}

bool BattleShip::Move::isValid(const BattleShip::Board &board) const {
    if (row <= 0 && row >= board.getNumRows()) {
        return false;
    }
    if (col <= 0 && col >= board.getNumCols()) {
        return false;
    }
    if (board.at(row, col) == board.hitChar){
        return false;
    }else{
        return true;
    }
}

//void Board::makeMove(int row, int col, char piece) {
//    this->at(row, col) = piece;
//
//}

void BattleShip::Move::displayResult() {
    for (auto ship : otherPlayer.ships){
        for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++){
            for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; i++){
                if (row == p && col == i){
                    std::cout << player.name << " hit " << otherPlayer.name << "'s "<< ship.piece << std::endl;
                    ship.health -= 1;
                }if (ship.health == 0){
                    std::cout << player.name << " destroyed " << otherPlayer.name << "'s " <<ship.piece << std::endl;
                    return;
                }else{
                    return;
                }
            }
        }
    }
    std::cout << "Missed." << std::endl;

}

