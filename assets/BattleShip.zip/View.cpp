//
// Created by Sarah Gerard on 2019-05-31.
//

#include <iostream>
#include "View.h"
#include "PlayerFiles/Player.h"


void BattleShip::View::showPlacementBoard(Player player) {
    Board boardCopy = player.getBoard();
    std::cout << player.name << "'s Placement Board"<< std::endl;
    boardCopy.display();
}

void BattleShip::View::showFiringBoard(BattleShip::Player player, BattleShip::Player otherPlayer) {
    Board boardCopy = player.getBoard();
    for (int i = 0; i < boardCopy.getNumCols(); i ++) {
        for (int p = 0; p < boardCopy.getNumRows(); p++) {
            if(boardCopy.at(p,i) != boardCopy.blankChar && boardCopy.at(p,i) != boardCopy.hitChar &&
                    boardCopy.at(p,i) != boardCopy.missChar) {
                boardCopy.at(p, i) = boardCopy.blankChar;

            }
        }
    }
    std::cout << otherPlayer.name << "'s Firing Board"<< std::endl;
    boardCopy.display();

}

BattleShip::Board BattleShip::View::makeFiringBoard(BattleShip::Player player) {
    for (int i = 0; i < player.board.getNumCols(); i ++) {
        for (int p = 0; p < player.board.getNumRows(); p++) {
            if(player.board.at(p,i) != player.board.blankChar && player.board.at(p,i) != player.board.hitChar) {
                player.board.at(p,i) = player.board.blankChar;

            }
        }
    }
    return player.board;
}

void BattleShip::View::showPlacementBoard(BattleShip::Player *player) {
    Board boardCopy = player->getBoard();
    std::cout << player->name << "'s Placement Board" << std::endl;
    boardCopy.display();

}

void BattleShip::View::showFiringBoard(BattleShip::Player *player, BattleShip::Player *otherPlayer) {
    Board boardCopy = player->getBoard();
    for (int i = 0; i < boardCopy.getNumCols(); i ++) {
        for (int p = 0; p < boardCopy.getNumRows(); p++) {
            if(boardCopy.at(p,i) != boardCopy.blankChar && boardCopy.at(p,i) != boardCopy.hitChar &&
               boardCopy.at(p,i) != boardCopy.missChar) {
                boardCopy.at(p, i) = boardCopy.blankChar;

            }
        }
    }
    std::cout << otherPlayer->name << "'s Firing Board"<< std::endl;
    boardCopy.display();

}