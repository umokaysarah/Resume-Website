//
// Created by Sarah Gerard on 2019-05-31.
//

#ifndef BATTLESHIP_GAMEATTRIBUTES_H
#define BATTLESHIP_GAMEATTRIBUTES_H

#include <vector>
#include <fstream>
#include "Board.h"
#include "Ship.h"


namespace BattleShip {
    class GameAttributes {
    public:
        explicit GameAttributes(std::ifstream &file);
        GameAttributes();
    protected:
        std::vector<Ship> ships;
        int totalShips;
        int rows;
        int cols;

        Board basicBoard;


    };
}


#endif //BATTLESHIP_GAMEATTRIBUTES_H
