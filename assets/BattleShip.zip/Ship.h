//
// Created by Sarah Gerard on 2019-05-31.
//

#ifndef BATTLESHIP_SHIP_H
#define BATTLESHIP_SHIP_H

#include "ShipPlacement.h"
namespace BattleShip{
class Ship {
public:
    Ship(int size, char piece);
    int size;
    char piece;
    int health;
    ShipPlacement placement;



};
}


#endif //BATTLESHIP_SHIP_H
