#include <iostream>
#include <string>
#include <fstream>
#include "BattleShipGame.h"
#include "GameTypeFiles/HumanVsHuman.h"
#include "GameTypeFiles/HumanVsAI.h"
#include "GameTypeFiles/AIVsAI.h"
#include "GameAttributes.h"

int main(int argc, char** argv) {
    std::ifstream file(argv[1]);
    //seed stuff
    int seed = -9999;
    if (argc >= 3) {
        seed = std::stoi(argv[2]);
    }

    //decide game type
    int HumVHum = 1, HumVAI = 2, AIVAI = 3;
    int type;
    while(true) {
        std::cout << "What type of game do you want to play?\n1. Human vs Human\n2. Human vs AI\n3. AI vs AI"
                  << std::endl;
        std::cout << "Your choice: ";
        std::cin >> type;
        if (type == HumVHum) {
            BattleShip::HumanVsHuman game(file);
            game.PlayGame();
            break;
        } else if (type == HumVAI) {
            if (seed != -9999) {
                BattleShip::AiPlayer::seed_random_number_generator(seed);
            }
            BattleShip::HumanVsAI game(file, seed);
            game.PlayGame();
            break;
        } else if (type == AIVAI) {
            if (seed != -9999) {
                BattleShip::AiPlayer::seed_random_number_generator(seed);
            }
            BattleShip::AIVsAI game(file, seed);
            game.PlayGame();
            break;
        } else {
            continue;
        }
    }


    return 0;
}