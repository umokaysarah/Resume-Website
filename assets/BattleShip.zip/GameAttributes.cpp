//
// Created by Sarah Gerard on 2019-05-31.
//

#include "GameAttributes.h"

BattleShip::GameAttributes::GameAttributes(std::ifstream &file){

    int a, b, c;
    int size;
    char piece;
    file >> a;
    file >> b;
    file >> c;
    while(file>> piece){
        file>>size;
        BattleShip::Ship newShip(size, piece);
        ships.emplace_back(newShip);
    }

    rows = a;
    cols = b;
    totalShips = c;
    Board board(rows, cols, '*');
    basicBoard = board;


}

BattleShip::GameAttributes::GameAttributes(): rows(0), cols(0), totalShips(0), basicBoard(0, 0, '*'), ships() {

}
