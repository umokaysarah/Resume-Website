//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_HUMANVSAI_H
#define BATTLESHIP_HUMANVSAI_H

#include "../PlayerFiles/Player.h"
#include "../Board.h"
#include "../BattleShipGame.h"
#include "../PlayerFiles/Utility.h"

namespace BattleShip {
    class HumanVsAI: public BattleShipGame {
    public:
        explicit HumanVsAI(std::ifstream &file, int seed);


        void PlayGame();

        Player* getCurPlayer();
        Player* getOtherPlayer();

        Move getValidAiMove(AiPlayer& player, HumanPlayer otherPlayer);
        Move getValidHumMove(HumanPlayer player, AiPlayer otherPlayer);
        Move getValidMove(Player* player, Player* otherPlayer);

        Move getCheatMove(AiPlayer player, HumanPlayer otherPlayer);
        Move getRandomMove(AiPlayer& player, HumanPlayer otherPlayer);
        Move getHuntMove(AiPlayer& player, HumanPlayer otherPlayer);

        void displayResult(Move move);
        bool GameOver();


        HumanPlayer first;
        AiPlayer second;

    };
}


#endif //BATTLESHIP_HUMANVSAI_H
