//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_AIVSAI_H
#define BATTLESHIP_AIVSAI_H

#include "../BattleShipGame.h"
#include "../PlayerFiles/Utility.h"

namespace BattleShip {
    class AIVsAI: public BattleShipGame {
    public:
        explicit AIVsAI(std::ifstream &file, int seed);

        void PlayGame();
        AiPlayer& getCurPlayer();
        AiPlayer& getOtherPlayer();

        Move getValidMove(AiPlayer& player, AiPlayer otherPlayer);

        Move getCheatMove(AiPlayer player, AiPlayer otherPlayer);
        Move getRandomMove(AiPlayer& player, AiPlayer otherPlayer);
        Move getHuntMove(AiPlayer& player, AiPlayer otherPlayer);

        void displayResult(Move move);
        bool GameOver();

        AiPlayer first;
        AiPlayer second;


    };
}


#endif //BATTLESHIP_AIVSAI_H
