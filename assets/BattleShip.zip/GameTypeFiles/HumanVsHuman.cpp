//
// Created by Sarah Gerard on 2019-05-30.
//

#include <iostream>
#include "HumanVsHuman.h"

BattleShip::HumanVsHuman::HumanVsHuman(std::ifstream &file) :
        BattleShipGame(file), first(makeHuman()), second(makeHuman()) {

}

void BattleShip::HumanVsHuman::PlayGame() {
    determineStartingPlayer();

    while (true) {
        getCurPlayer().view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
        std::cout<<"\n"<<std::endl;
        getCurPlayer().view.showPlacementBoard(getCurPlayer());
        //get move
        Move move = getValidMove(getCurPlayer(), getOtherPlayer());

        //make move
        getOtherPlayer().getBoard().makeMove(move);
       // getOtherPlayer().board.at(0, 0) = getOtherPlayer().board.hitChar;
        getCurPlayer().view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
        std::cout<<"\n"<<std::endl;
        getCurPlayer().view.showPlacementBoard(getCurPlayer());
        displayResult(move);
        //makeMove(move);
        //board.display();
        if (GameOver()) {
            break;
        }
        //switch the turn
        changeTurn();
    }


}

BattleShip::HumanPlayer& BattleShip::HumanVsHuman::getCurPlayer() {
    if (playerTurn == 0) {
        return first;
    }else{
        return second;
    }
}


BattleShip::HumanPlayer& BattleShip::HumanVsHuman::getOtherPlayer() {
    if (playerTurn == 0){
        return second;
    }else{
        return first;
    }
}


BattleShip::Move
BattleShip::HumanVsHuman::getValidMove(BattleShip::HumanPlayer player, BattleShip::HumanPlayer otherPlayer) {
    Move playerMove(player, otherPlayer);
    do{
        std::cout << player.name <<", where would you like to fire?" << std::endl;
        std::cout << "Enter your attack coordinate in the form row col: ";
        std::cin >> playerMove.row >> playerMove.col;
    } while (!playerMove.isValid(player.view.makeFiringBoard(otherPlayer)));
    return playerMove;
}

bool BattleShip::HumanVsHuman::GameOver() {
    for (auto ship : getOtherPlayer().ships){
        if (ship.health != 0){
            return false;
        }
    }
    std::cout<<"\n"<<std::endl;
    std::cout<< getCurPlayer().name << " won the game!" << std::endl;
    return true;
}


void BattleShip::HumanVsHuman::displayResult(Move move) {
    for (auto& ship : getOtherPlayer().ships){
        for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++){
            for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; p++){
                if (move.row == p && move.col == i) {
                    std::cout << getCurPlayer().name << " hit " << getOtherPlayer().name << "'s " << ship.piece
                            << "!" << std::endl;
                    ship.health --;
                    if (ship.health == 0) {
                        std::cout << getCurPlayer().name << " destroyed " << getOtherPlayer().name << "'s "
                                  << ship.piece << "!"<< std::endl;
                        return;
                    } else {
                        return;
                    }
                }
            }
        }
    }
    std::cout << "Missed." << std::endl;

}