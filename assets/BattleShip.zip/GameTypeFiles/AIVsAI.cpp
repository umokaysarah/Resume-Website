//
// Created by Sarah Gerard on 2019-05-30.
//

#include "AIVsAI.h"

BattleShip::AIVsAI::AIVsAI(std::ifstream &file, int seed) :
BattleShipGame(file), first(makeAI()), second(makeAI()) {

}

BattleShip::AiPlayer& BattleShip::AIVsAI::getCurPlayer() {
    if (playerTurn == 0) {
        return first;
    }else{
        return second;
    }
}

BattleShip::AiPlayer& BattleShip::AIVsAI::getOtherPlayer() {
    if (playerTurn == 1) {
        return first;
    }else{
        return second;
    }
}


void BattleShip::AIVsAI::PlayGame() {
    determineStartingPlayer();

    while (true) {
       // getCurPlayer().view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
       // std::cout<<"\n"<<std::endl;
       // getCurPlayer().view.showPlacementBoard(getCurPlayer());
        //get move
        Move move = getValidMove(getCurPlayer(), getOtherPlayer());

        //make move
        getOtherPlayer().board.makeMove(move);

        getCurPlayer().view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
        std::cout<<"\n"<<std::endl;
        getCurPlayer().view.showPlacementBoard(getCurPlayer());
        displayResult(move);
        //makeMove(move);
        //board.display();
        if (GameOver()) {
            break;
        }
        //switch the turn
        changeTurn();
    }


}

bool BattleShip::AIVsAI::GameOver() {
    for (auto ship : getOtherPlayer().ships){
        if (ship.health > 0){
            return false;
        }
    }
    std::cout<<"\n"<<std::endl;
    std::cout<< getCurPlayer().name << " won the game!" << std::endl;
    return true;
}


    BattleShip::Move BattleShip::AIVsAI::getValidMove(BattleShip::AiPlayer& player, BattleShip::AiPlayer otherPlayer) {
    if(player.type == 1){
        Move move = getCheatMove(player, otherPlayer);
        return move;
    }else if (player.type == 2){
        Move move = getRandomMove(player, otherPlayer);
        return move;
    }else{
        Move move = getHuntMove(player, otherPlayer);
        return move;
    }
}

BattleShip::Move BattleShip::AIVsAI::getCheatMove(BattleShip::AiPlayer player, BattleShip::AiPlayer otherPlayer) {
    Move playerMove(player, otherPlayer);
    for(int p = 0; p < player.board.getNumRows(); p++){
        for (int i = 0; i < player.board.getNumCols(); i++){
            if(otherPlayer.board.at(p,i) != otherPlayer.board.blankChar &&
            otherPlayer.board.at(p,i) != otherPlayer.board.hitChar){
                playerMove.col = i;
                playerMove.row = p;
                return playerMove;
            }
        }
    }
    return playerMove;
}

BattleShip::Move BattleShip::AIVsAI::getHuntMove(BattleShip::AiPlayer& player, BattleShip::AiPlayer otherPlayer) {
    for (auto ship : otherPlayer.ships){
        if (ship.health <= 0 || ship.health == ship.size){
            //continue
        }else{ //destroy mode
            Move playerMove(player, otherPlayer);
            for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++) {
                for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; p++) {
                    if(otherPlayer.board.at(p,i) == otherPlayer.board.hitChar) {
                        if(otherPlayer.board.at(p+1, i)== otherPlayer.board.hitChar){

                        }else if(otherPlayer.board.at(p, i+1)== otherPlayer.board.hitChar){

                        }else if(i > 0 && otherPlayer.board.at(p,i - 1) != otherPlayer.board.hitChar &&
                                otherPlayer.board.at(p,i - 1) != otherPlayer.board.missChar){
                            playerMove.col = i - 1;
                            playerMove.row = p;
                            return playerMove;
                        }else if(p > 0 && otherPlayer.board.at(p - 1,i) != otherPlayer.board.hitChar
                                && otherPlayer.board.at(p - 1,i) != otherPlayer.board.missChar){
                            playerMove.col = i;
                            playerMove.row = p - 1;
                            return playerMove;
                        }else if(i < otherPlayer.board.getNumCols() &&
                                 otherPlayer.board.at(p,i + 1) != otherPlayer.board.hitChar &&
                                otherPlayer.board.at(p,i + 1) != otherPlayer.board.missChar){
                            playerMove.col = i + 1;
                            playerMove.row = p;
                            return playerMove;
                        }else if(p < otherPlayer.board.getNumRows() &&
                                 otherPlayer.board.at(p + 1,i) != otherPlayer.board.hitChar &&
                                otherPlayer.board.at(p + 1,i) != otherPlayer.board.missChar){
                            playerMove.col = i;
                            playerMove.row = p + 1;
                            return playerMove;
                        }else{
                            //continue
                        }
                    }else{
                        //continue
                    }
                }
            }
            return playerMove;
        }

    }

    Move playerMove = getRandomMove(player, otherPlayer);
    return playerMove;
}


BattleShip::Move BattleShip::AIVsAI::getRandomMove(BattleShip::AiPlayer& player, BattleShip::AiPlayer otherPlayer) {
    Move move(player, otherPlayer);
    std::pair<int, int> playerMove = *chooseRandom(player.possibleMoves, AiPlayer::randomNumberGenerator);
    move.row = playerMove.first;
    move.col = playerMove.second;
    for (int i = 0; i < player.possibleMoves.size(); i++) {
        if (player.possibleMoves[i] == playerMove) {
            player.getPossibleMoves().erase(player.possibleMoves.begin() + i);
        }
    }
    return move;
}

void BattleShip::AIVsAI::displayResult(BattleShip::Move move) {
    for (auto& ship : getOtherPlayer().ships){
        for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++){
            for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; p++){
                if (move.row == p && move.col == i) {
                    std::cout << getCurPlayer().name << " hit " << getOtherPlayer().name << "'s " << ship.piece
                             << "!" << std::endl;
                    ship.health --;
                    if (ship.health == 0) {
                        std::cout << getCurPlayer().name << " destroyed " << getOtherPlayer().name << "'s "
                                  << ship.piece << "!"<< "\n" << std::endl;
                        return;
                    } else {
                        std::cout<< std::endl;
                        return;
                    }
                }
            }
        }
    }
    std::cout << "Missed." << std::endl;
    std::cout << std::endl;

}










