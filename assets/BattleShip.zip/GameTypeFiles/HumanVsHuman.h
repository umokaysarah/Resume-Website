//
// Created by Sarah Gerard on 2019-05-30.
//

#ifndef BATTLESHIP_HUMANVSHUMAN_H
#define BATTLESHIP_HUMANVSHUMAN_H

#include "../PlayerFiles/Player.h"
#include "../Board.h"
#include "../BattleShipGame.h"
namespace BattleShip {

    class HumanVsHuman : public BattleShipGame {
    public:
        explicit HumanVsHuman(std::ifstream &file);

        void PlayGame();
        HumanPlayer& getCurPlayer();
        HumanPlayer& getOtherPlayer();

        Move getValidMove(HumanPlayer player, HumanPlayer otherPlayer);
        void displayResult(Move move);

        bool GameOver();

        HumanPlayer first;
        HumanPlayer second;

    };
}


#endif //BATTLESHIP_HUMANVSHUMAN_H
