//
// Created by Sarah Gerard on 2019-05-30.
//

#include "HumanVsAI.h"


BattleShip::HumanVsAI::HumanVsAI(std::ifstream &file, int seed) :
        BattleShipGame(file), first(makeHuman()), second(makeAI()) {
    if (seed != -9999) {
        AiPlayer::seed_random_number_generator(seed);
    }

}

void BattleShip::HumanVsAI::PlayGame() {
    determineStartingPlayer();

    while (true) {
        if(getCurPlayer() == &first) {
            getCurPlayer()->view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
            std::cout << "\n" << std::endl;
            getCurPlayer()->view.showPlacementBoard(getCurPlayer());
        }

        //get move
        Move move = getValidMove(getCurPlayer(), getOtherPlayer());
        //make move
        getOtherPlayer()->board.makeMove(move);

        getCurPlayer()->view.showFiringBoard(getOtherPlayer(), getCurPlayer()); //show the game state
        std::cout<<"\n"<<std::endl;
        getCurPlayer()->view.showPlacementBoard(getCurPlayer());
        //move.displayResult();
        displayResult(move);
        std::cout<< std::endl;
        //makeMove(move);
        //board.display();
        if (GameOver()) {
            break;
        }
        //switch the turn
        changeTurn();
    }

}


BattleShip::Player *BattleShip::HumanVsAI::getCurPlayer() {
    Player* ptr;
    if (playerTurn == 0) {
        ptr = &first;
        return ptr;
    }else{
        ptr = &second;
        return ptr;
    }
}

BattleShip::Player *BattleShip::HumanVsAI::getOtherPlayer() {
    Player* ptr;
    if (playerTurn == 0) {
        ptr = &second;
        return ptr;
    }else{
        ptr = &first;
        return ptr;
    }
}

bool BattleShip::HumanVsAI::GameOver() {
    for (auto ship : getOtherPlayer()->ships){
        if (ship.health != 0){
            return false;
        }
    }
    std::cout<<"\n"<<std::endl;
    std::cout<< getCurPlayer()->name << " won the game!" << std::endl;
    return true;
}

BattleShip::Move BattleShip::HumanVsAI::getCheatMove(BattleShip::AiPlayer player, BattleShip::HumanPlayer otherPlayer) {
    Move playerMove(player, otherPlayer);
    for(int p = 0; p < player.board.getNumRows(); p++){
        for (int i = 0; i < player.board.getNumCols(); i++){
            if(otherPlayer.board.at(p,i) != otherPlayer.board.blankChar &&
               otherPlayer.board.at(p,i) != otherPlayer.board.hitChar){
                playerMove.col = i;
                playerMove.row = p;
                return playerMove;
            }
        }
    }
    return playerMove;
}

BattleShip::Move BattleShip::HumanVsAI::getHuntMove(BattleShip::AiPlayer& player, BattleShip::HumanPlayer otherPlayer) {
    for (auto ship : otherPlayer.ships){
        if (ship.health <= 0 || ship.health == ship.size){
            //continue
        }else{ //destroy mode
            Move playerMove(player, otherPlayer);
            for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++) {
                for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; p++) {
                    if(otherPlayer.board.at(p,i) == otherPlayer.board.hitChar) {
                        if(otherPlayer.board.at(p+1, i)== otherPlayer.board.hitChar){

                        }else if(otherPlayer.board.at(p, i+1)== otherPlayer.board.hitChar){

                        }else if(i > 0 && otherPlayer.board.at(p,i - 1) != otherPlayer.board.hitChar &&
                           otherPlayer.board.at(p,i - 1) != otherPlayer.board.missChar){
                            playerMove.col = i - 1;
                            playerMove.row = p;
                            return playerMove;
                        }else if(p > 0 && otherPlayer.board.at(p - 1,i) != otherPlayer.board.hitChar
                                 && otherPlayer.board.at(p - 1,i) != otherPlayer.board.missChar){
                            playerMove.col = i;
                            playerMove.row = p - 1;
                            return playerMove;
                        }else if(i < otherPlayer.board.getNumCols() &&
                                 otherPlayer.board.at(p,i + 1) != otherPlayer.board.hitChar &&
                                 otherPlayer.board.at(p,i + 1) != otherPlayer.board.missChar){
                            playerMove.col = i + 1;
                            playerMove.row = p;
                            return playerMove;
                        }else if(p < otherPlayer.board.getNumRows() &&
                                 otherPlayer.board.at(p + 1,i) != otherPlayer.board.hitChar &&
                                 otherPlayer.board.at(p + 1,i) != otherPlayer.board.missChar){
                            playerMove.col = i;
                            playerMove.row = p + 1;
                            return playerMove;
                        }else{
                            //continue
                        }
                    }else{
                        //continue
                    }
                }
            }
            return playerMove;
        }

    }

    Move playerMove = getRandomMove(player, otherPlayer);
    return playerMove;
}


BattleShip::Move BattleShip::HumanVsAI::getValidMove(BattleShip::Player *player, BattleShip::Player *otherPlayer) {
    HumanPlayer* human = dynamic_cast<HumanPlayer*>(player);
    AiPlayer* Ai = dynamic_cast<AiPlayer*>(otherPlayer);
    if(human == nullptr){
        Ai = dynamic_cast<AiPlayer*>(player);
        human = dynamic_cast<HumanPlayer*>(otherPlayer);
        Move move = getValidAiMove(*Ai, *human);
        return move;
    }else{
        Move move = getValidHumMove(*human, *Ai);
        return move;
    }

}

BattleShip::Move
BattleShip::HumanVsAI::getValidAiMove(BattleShip::AiPlayer& player, BattleShip::HumanPlayer otherPlayer) {
    if(player.type == 1){
        Move move = getCheatMove(player, otherPlayer);
        return move;
    }else if (player.type == 2){
        Move move = getRandomMove(player, otherPlayer);
        return move;
    }else{
        Move move = getHuntMove(player, otherPlayer);
        return move;
    }
}

BattleShip::Move
BattleShip::HumanVsAI::getValidHumMove(BattleShip::HumanPlayer player, BattleShip::AiPlayer otherPlayer) {
    Move playerMove(player, otherPlayer);
    do{
        std::cout << player.name <<", where would you like to fire?" << std::endl;
        std::cout << "Enter your attack coordinate in the form row col: ";
        std::cin >> playerMove.row >> playerMove.col;
    } while (!playerMove.isValid(player.view.makeFiringBoard(otherPlayer)));
    return playerMove;
}

BattleShip::Move
BattleShip::HumanVsAI::getRandomMove(BattleShip::AiPlayer& player, BattleShip::HumanPlayer otherPlayer) {
    Move move(player, otherPlayer);
    std::pair<int, int> playerMove = *chooseRandom(player.possibleMoves, AiPlayer::randomNumberGenerator);
    move.row = playerMove.first;
    move.col = playerMove.second;
    for (int i = 0; i < player.possibleMoves.size(); i++) {
        if (player.possibleMoves[i] == playerMove) {
            player.getPossibleMoves().erase(player.possibleMoves.begin() + i);
        }
    }
    return move;
}


void BattleShip::HumanVsAI::displayResult(Move move) {
    for (auto& ship : getOtherPlayer()->ships){
        for (int i = ship.placement.colStart; i <= ship.placement.colEnd; i++){
            for (int p = ship.placement.rowStart; p <= ship.placement.rowEnd; p++){
                if (move.row == p && move.col == i) {
                    std::cout << getCurPlayer()->name << " hit " << getOtherPlayer()->name << "'s " << ship.piece
                              << "!" << std::endl;
                    ship.health --;
                    if (ship.health == 0) {
                        std::cout << getCurPlayer()->name << " destroyed " << getOtherPlayer()->name << "'s "
                                  << ship.piece << "!"<< "\n" << std::endl;

                        return;
                    } else {
                        return;
                    }
                }
            }
        }
    }
    std::cout << "Missed." << std::endl;

}









