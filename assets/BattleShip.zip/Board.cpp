//
// Created by Sarah Gerard on 2019-05-30.
//

#include <iostream>
#include "Board.h"
#include "Ship.h"
#include "Move.h"

BattleShip::Board::Board(int rows, int cols, char blankchar):
boardState(rows, std::string(cols, blankchar)), rows(rows), cols(cols), blankChar(blankchar), hitChar('X'), missChar('O') {

}

BattleShip::Board::Board(): rows(0), cols(0), blankChar('*'), hitChar('X'), missChar('O') {

}

char &BattleShip::Board::at(int row, int col) {
    return boardState.at(row).at(col);
}

const char BattleShip::Board::at(int row, int col) const {
    return boardState.at(row).at(col);
}


const int BattleShip::Board::getNumRows() const {
    return rows;
}

const int BattleShip::Board::getNumCols() const {
    return cols;
}

bool BattleShip::Board::canPlaceShipAt(BattleShip::ShipPlacement place) const {
    if (place.colStart >= 0 && place.colEnd < cols) {

    }else{
        return false;
    }
    if(place.rowStart >= 0 && place.rowEnd < rows){

    }else{
        return false;
    }
    for(int i = place.colStart; i <= place.colEnd; i ++){
        for(int p = place.rowStart; p <= place.rowEnd; p ++){
            if(this->at(p,i) != blankChar){
                return false;
            }
        }
    }
    return true;
}

void BattleShip::Board::AddShip(char ship, BattleShip::ShipPlacement place) {
    for (int i = place.colStart; i <= place.colEnd; i++) {
        for (int p = place.rowStart; p <= place.rowEnd; p++) {
            this->at(p, i) = ship;
        }
    }
}

void BattleShip::Board::display() {
    std::cout << "  " ;
    for (int i = 0; i < cols; ++i) {
        std::cout << i << ' ';
    }
    std::cout << std::endl;

    int rowIndex = 0;
    for (const auto& row : boardState) {
        std::cout << rowIndex << ' ';
        for(const auto& elem : row){
            std::cout << elem << ' ';
        }
        rowIndex++;
        std::cout << std::endl;
    }

}

void BattleShip::Board::makeMove(BattleShip::Move move) {
    if(this->at(move.row, move.col) != blankChar) {
        this->at(move.row, move.col) = hitChar;
    }else{
        this->at(move.row, move.col) = missChar;
    }

}

