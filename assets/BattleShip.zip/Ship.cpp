//
// Created by Sarah Gerard on 2019-05-31.
//

#include "Ship.h"


BattleShip::Ship::Ship(int size, char piece): size(size), piece(piece), health(size), placement() {

}
