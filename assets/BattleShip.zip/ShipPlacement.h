//
// Created by Sarah Gerard on 2019-06-01.
//

#ifndef BATTLESHIP_SHIPPLACEMENT_H
#define BATTLESHIP_SHIPPLACEMENT_H

namespace BattleShip {
    class ShipPlacement {
    public:
        ShipPlacement() = default;
        int rowStart;
        int rowEnd;
        int colStart;
        int colEnd;

    };
}

#endif //BATTLESHIP_SHIPPLACEMENT_H
